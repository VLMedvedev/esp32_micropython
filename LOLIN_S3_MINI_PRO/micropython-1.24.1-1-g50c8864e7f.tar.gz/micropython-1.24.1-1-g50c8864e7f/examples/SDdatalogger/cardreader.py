# cardread.py
# This is called when the user enters cardreader mode. It does nothing.
